﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculationResultText = new System.Windows.Forms.Label();
            this.buttonPanel = new System.Windows.Forms.TableLayoutPanel();
            this.CEButton = new System.Windows.Forms.Button();
            this.CButton = new System.Windows.Forms.Button();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.SignChangeButton = new System.Windows.Forms.Button();
            this.Button8 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button0 = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.Button9 = new System.Windows.Forms.Button();
            this.Button6 = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.DecimalButton = new System.Windows.Forms.Button();
            this.DivideButton = new System.Windows.Forms.Button();
            this.MultiplyButton = new System.Windows.Forms.Button();
            this.SubtractButton = new System.Windows.Forms.Button();
            this.AddButton = new System.Windows.Forms.Button();
            this.EqualsButton = new System.Windows.Forms.Button();
            this.userInputText = new System.Windows.Forms.Label();
            this.buttonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // calculationResultText
            // 
            this.calculationResultText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.calculationResultText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculationResultText.Location = new System.Drawing.Point(12, 35);
            this.calculationResultText.Name = "calculationResultText";
            this.calculationResultText.Size = new System.Drawing.Size(225, 31);
            this.calculationResultText.TabIndex = 1;
            this.calculationResultText.Text = "0";
            this.calculationResultText.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // buttonPanel
            // 
            this.buttonPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonPanel.ColumnCount = 4;
            this.buttonPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.buttonPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.buttonPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.buttonPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.buttonPanel.Controls.Add(this.CEButton, 0, 0);
            this.buttonPanel.Controls.Add(this.CButton, 1, 0);
            this.buttonPanel.Controls.Add(this.Button7, 0, 1);
            this.buttonPanel.Controls.Add(this.Button4, 0, 2);
            this.buttonPanel.Controls.Add(this.Button1, 0, 3);
            this.buttonPanel.Controls.Add(this.SignChangeButton, 0, 4);
            this.buttonPanel.Controls.Add(this.Button8, 1, 1);
            this.buttonPanel.Controls.Add(this.Button5, 1, 2);
            this.buttonPanel.Controls.Add(this.Button2, 1, 3);
            this.buttonPanel.Controls.Add(this.Button0, 1, 4);
            this.buttonPanel.Controls.Add(this.BackButton, 2, 0);
            this.buttonPanel.Controls.Add(this.Button9, 2, 1);
            this.buttonPanel.Controls.Add(this.Button6, 2, 2);
            this.buttonPanel.Controls.Add(this.Button3, 2, 3);
            this.buttonPanel.Controls.Add(this.DecimalButton, 2, 4);
            this.buttonPanel.Controls.Add(this.DivideButton, 3, 0);
            this.buttonPanel.Controls.Add(this.MultiplyButton, 3, 1);
            this.buttonPanel.Controls.Add(this.SubtractButton, 3, 2);
            this.buttonPanel.Controls.Add(this.AddButton, 3, 3);
            this.buttonPanel.Controls.Add(this.EqualsButton, 3, 4);
            this.buttonPanel.Location = new System.Drawing.Point(15, 69);
            this.buttonPanel.Name = "buttonPanel";
            this.buttonPanel.RowCount = 5;
            this.buttonPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.buttonPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.buttonPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.buttonPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.buttonPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.buttonPanel.Size = new System.Drawing.Size(222, 230);
            this.buttonPanel.TabIndex = 2;
            // 
            // CEButton
            // 
            this.CEButton.BackColor = System.Drawing.Color.Black;
            this.CEButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CEButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CEButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CEButton.Location = new System.Drawing.Point(0, 0);
            this.CEButton.Margin = new System.Windows.Forms.Padding(0);
            this.CEButton.Name = "CEButton";
            this.CEButton.Size = new System.Drawing.Size(55, 46);
            this.CEButton.TabIndex = 0;
            this.CEButton.Text = "CE";
            this.CEButton.UseVisualStyleBackColor = false;
            this.CEButton.Click += new System.EventHandler(this.CEButton_Click);
            // 
            // CButton
            // 
            this.CButton.BackColor = System.Drawing.Color.Black;
            this.CButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CButton.Location = new System.Drawing.Point(55, 0);
            this.CButton.Margin = new System.Windows.Forms.Padding(0);
            this.CButton.Name = "CButton";
            this.CButton.Size = new System.Drawing.Size(55, 46);
            this.CButton.TabIndex = 1;
            this.CButton.Text = "C";
            this.CButton.UseVisualStyleBackColor = false;
            this.CButton.Click += new System.EventHandler(this.CButton_Click);
            // 
            // Button7
            // 
            this.Button7.BackColor = System.Drawing.Color.Black;
            this.Button7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button7.Location = new System.Drawing.Point(0, 46);
            this.Button7.Margin = new System.Windows.Forms.Padding(0);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(55, 46);
            this.Button7.TabIndex = 2;
            this.Button7.Text = "7";
            this.Button7.UseVisualStyleBackColor = false;
            this.Button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // Button4
            // 
            this.Button4.BackColor = System.Drawing.Color.Black;
            this.Button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button4.Location = new System.Drawing.Point(0, 92);
            this.Button4.Margin = new System.Windows.Forms.Padding(0);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(55, 46);
            this.Button4.TabIndex = 3;
            this.Button4.Text = "4";
            this.Button4.UseVisualStyleBackColor = false;
            this.Button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.Color.Black;
            this.Button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button1.Location = new System.Drawing.Point(0, 138);
            this.Button1.Margin = new System.Windows.Forms.Padding(0);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(55, 46);
            this.Button1.TabIndex = 4;
            this.Button1.Text = "1";
            this.Button1.UseVisualStyleBackColor = false;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // SignChangeButton
            // 
            this.SignChangeButton.BackColor = System.Drawing.Color.Black;
            this.SignChangeButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SignChangeButton.Location = new System.Drawing.Point(0, 184);
            this.SignChangeButton.Margin = new System.Windows.Forms.Padding(0);
            this.SignChangeButton.Name = "SignChangeButton";
            this.SignChangeButton.Size = new System.Drawing.Size(55, 46);
            this.SignChangeButton.TabIndex = 5;
            this.SignChangeButton.Text = "+/-";
            this.SignChangeButton.UseVisualStyleBackColor = false;
            this.SignChangeButton.Click += new System.EventHandler(this.SignChangeButton_Click);
            // 
            // Button8
            // 
            this.Button8.BackColor = System.Drawing.Color.Black;
            this.Button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button8.Location = new System.Drawing.Point(55, 46);
            this.Button8.Margin = new System.Windows.Forms.Padding(0);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(55, 46);
            this.Button8.TabIndex = 6;
            this.Button8.Text = "8";
            this.Button8.UseVisualStyleBackColor = false;
            this.Button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // Button5
            // 
            this.Button5.BackColor = System.Drawing.Color.Black;
            this.Button5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button5.Location = new System.Drawing.Point(55, 92);
            this.Button5.Margin = new System.Windows.Forms.Padding(0);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(55, 46);
            this.Button5.TabIndex = 7;
            this.Button5.Text = "5";
            this.Button5.UseVisualStyleBackColor = false;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // Button2
            // 
            this.Button2.BackColor = System.Drawing.Color.Black;
            this.Button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button2.Location = new System.Drawing.Point(55, 138);
            this.Button2.Margin = new System.Windows.Forms.Padding(0);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(55, 46);
            this.Button2.TabIndex = 8;
            this.Button2.Text = "2";
            this.Button2.UseVisualStyleBackColor = false;
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Button0
            // 
            this.Button0.BackColor = System.Drawing.Color.Black;
            this.Button0.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button0.Location = new System.Drawing.Point(55, 184);
            this.Button0.Margin = new System.Windows.Forms.Padding(0);
            this.Button0.Name = "Button0";
            this.Button0.Size = new System.Drawing.Size(55, 46);
            this.Button0.TabIndex = 9;
            this.Button0.Text = "0";
            this.Button0.UseVisualStyleBackColor = false;
            this.Button0.Click += new System.EventHandler(this.Button0_Click);
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.Black;
            this.BackButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BackButton.Location = new System.Drawing.Point(110, 0);
            this.BackButton.Margin = new System.Windows.Forms.Padding(0);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(55, 46);
            this.BackButton.TabIndex = 10;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // Button9
            // 
            this.Button9.BackColor = System.Drawing.Color.Black;
            this.Button9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button9.Location = new System.Drawing.Point(110, 46);
            this.Button9.Margin = new System.Windows.Forms.Padding(0);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(55, 46);
            this.Button9.TabIndex = 11;
            this.Button9.Text = "9";
            this.Button9.UseVisualStyleBackColor = false;
            this.Button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // Button6
            // 
            this.Button6.BackColor = System.Drawing.Color.Black;
            this.Button6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button6.Location = new System.Drawing.Point(110, 92);
            this.Button6.Margin = new System.Windows.Forms.Padding(0);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(55, 46);
            this.Button6.TabIndex = 12;
            this.Button6.Text = "6";
            this.Button6.UseVisualStyleBackColor = false;
            this.Button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // Button3
            // 
            this.Button3.BackColor = System.Drawing.Color.Black;
            this.Button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Button3.Location = new System.Drawing.Point(110, 138);
            this.Button3.Margin = new System.Windows.Forms.Padding(0);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(55, 46);
            this.Button3.TabIndex = 13;
            this.Button3.Text = "3";
            this.Button3.UseVisualStyleBackColor = false;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // DecimalButton
            // 
            this.DecimalButton.BackColor = System.Drawing.Color.Black;
            this.DecimalButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DecimalButton.Location = new System.Drawing.Point(110, 184);
            this.DecimalButton.Margin = new System.Windows.Forms.Padding(0);
            this.DecimalButton.Name = "DecimalButton";
            this.DecimalButton.Size = new System.Drawing.Size(55, 46);
            this.DecimalButton.TabIndex = 14;
            this.DecimalButton.Text = ".";
            this.DecimalButton.UseVisualStyleBackColor = false;
            this.DecimalButton.Click += new System.EventHandler(this.DecimalButton_Click);
            // 
            // DivideButton
            // 
            this.DivideButton.BackColor = System.Drawing.Color.Black;
            this.DivideButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DivideButton.Location = new System.Drawing.Point(165, 0);
            this.DivideButton.Margin = new System.Windows.Forms.Padding(0);
            this.DivideButton.Name = "DivideButton";
            this.DivideButton.Size = new System.Drawing.Size(57, 46);
            this.DivideButton.TabIndex = 15;
            this.DivideButton.Text = "/";
            this.DivideButton.UseVisualStyleBackColor = false;
            this.DivideButton.Click += new System.EventHandler(this.DivideButton_Click);
            // 
            // MultiplyButton
            // 
            this.MultiplyButton.BackColor = System.Drawing.Color.Black;
            this.MultiplyButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MultiplyButton.Location = new System.Drawing.Point(165, 46);
            this.MultiplyButton.Margin = new System.Windows.Forms.Padding(0);
            this.MultiplyButton.Name = "MultiplyButton";
            this.MultiplyButton.Size = new System.Drawing.Size(57, 46);
            this.MultiplyButton.TabIndex = 16;
            this.MultiplyButton.Text = "X";
            this.MultiplyButton.UseVisualStyleBackColor = false;
            this.MultiplyButton.Click += new System.EventHandler(this.MultiplyButton_Click);
            // 
            // SubtractButton
            // 
            this.SubtractButton.BackColor = System.Drawing.Color.Black;
            this.SubtractButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SubtractButton.Location = new System.Drawing.Point(165, 92);
            this.SubtractButton.Margin = new System.Windows.Forms.Padding(0);
            this.SubtractButton.Name = "SubtractButton";
            this.SubtractButton.Size = new System.Drawing.Size(57, 46);
            this.SubtractButton.TabIndex = 17;
            this.SubtractButton.Text = "-";
            this.SubtractButton.UseVisualStyleBackColor = false;
            this.SubtractButton.Click += new System.EventHandler(this.SubtractButton_Click);
            // 
            // AddButton
            // 
            this.AddButton.BackColor = System.Drawing.Color.Black;
            this.AddButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddButton.Location = new System.Drawing.Point(165, 138);
            this.AddButton.Margin = new System.Windows.Forms.Padding(0);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(57, 46);
            this.AddButton.TabIndex = 18;
            this.AddButton.Text = "+";
            this.AddButton.UseVisualStyleBackColor = false;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // EqualsButton
            // 
            this.EqualsButton.BackColor = System.Drawing.Color.Black;
            this.EqualsButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EqualsButton.Location = new System.Drawing.Point(165, 184);
            this.EqualsButton.Margin = new System.Windows.Forms.Padding(0);
            this.EqualsButton.Name = "EqualsButton";
            this.EqualsButton.Size = new System.Drawing.Size(57, 46);
            this.EqualsButton.TabIndex = 19;
            this.EqualsButton.Text = "=";
            this.EqualsButton.UseVisualStyleBackColor = false;
            this.EqualsButton.Click += new System.EventHandler(this.EqualsButton_Click);
            // 
            // userInputText
            // 
            this.userInputText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.userInputText.Location = new System.Drawing.Point(15, 9);
            this.userInputText.Name = "userInputText";
            this.userInputText.Size = new System.Drawing.Size(222, 17);
            this.userInputText.TabIndex = 3;
            this.userInputText.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Form1
            // 
            this.AcceptButton = this.EqualsButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CancelButton = this.CEButton;
            this.ClientSize = new System.Drawing.Size(249, 311);
            this.Controls.Add(this.userInputText);
            this.Controls.Add(this.buttonPanel);
            this.Controls.Add(this.calculationResultText);
            this.ForeColor = System.Drawing.Color.White;
            this.MinimumSize = new System.Drawing.Size(265, 350);
            this.Name = "Form1";
            this.Text = "Calculator";
            this.buttonPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label calculationResultText;
        private System.Windows.Forms.TableLayoutPanel buttonPanel;
        private System.Windows.Forms.Button CEButton;
        private System.Windows.Forms.Button CButton;
        private System.Windows.Forms.Button Button7;
        private System.Windows.Forms.Button Button4;
        private System.Windows.Forms.Button Button1;
        private System.Windows.Forms.Button SignChangeButton;
        private System.Windows.Forms.Button Button8;
        private System.Windows.Forms.Button Button5;
        private System.Windows.Forms.Button Button2;
        private System.Windows.Forms.Button Button0;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button Button9;
        private System.Windows.Forms.Button Button6;
        private System.Windows.Forms.Button Button3;
        private System.Windows.Forms.Button DecimalButton;
        private System.Windows.Forms.Button DivideButton;
        private System.Windows.Forms.Button MultiplyButton;
        private System.Windows.Forms.Button SubtractButton;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Button EqualsButton;
        private System.Windows.Forms.Label userInputText;
    }
}

