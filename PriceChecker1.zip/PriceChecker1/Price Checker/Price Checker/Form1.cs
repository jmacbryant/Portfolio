﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Price_Checker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dbButton_Click(object sender, EventArgs e)
        {
            //Obtaining the data source
            var Inventory = new InventoryDataContext();

            // Create the query
            var query = from c in Inventory.Products
                        select c;


            dbOutput.Text += "\n UPC \t ProductBrand \t ProductModel \t ProductYear \t Price \t CreatedBy \t CreatedDate \t UpdatedBy \t UpdatedDate \t RowStamp";
            // Execute the query
            foreach (var c in query)
            {
                //dbOutput.Text += "\n" + (c.ProductBrand);
                dbOutput.Text += "\n" + c.UPC + " _ " + c.ProductBrand + " _ " + c.ProductModel + " _ " + c.ProductYear.Year + " _ " + c.Price + " _ " + c.CreatedBy + " _ " + c.CreatedDate + " _ " + c.UpdatedBy + " _ " + c.UpdatedDate + " _ " + c.RowStamp;
            }
        }
    }
}
