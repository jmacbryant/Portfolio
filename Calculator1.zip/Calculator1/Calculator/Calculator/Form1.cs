﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// 
        /// Basic Windows Forms Application:
        /// 
        /// ----------Calculator------------
        ///
        /// </summary>

        #region Constructor

        /// <summary>
        /// Default Constructor
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        #endregion

        #region Clear Methods

        /// <summary>
        /// Clears the user input text
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void CEButton_Click(object sender, EventArgs e)
        {
            // Clears the text from the user input textbox
            this.userInputText.Text = string.Empty;

            FocusInputText();
        }

        /// <summary>
        /// Clears the user input text
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void CButton_Click(object sender, EventArgs e)
        {
            // Clears the text from the user input textbox
            this.userInputText.Text = string.Empty;

            FocusInputText();
        }

        /// <summary>
        /// Deletes the last character of the input text
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void BackButton_Click(object sender, EventArgs e)
        {
            // Delete the value to the right of selection start
            deleteText();

            FocusInputText();
        }

        ///// <summary>
        ///// Deletes the last character of the input text
        ///// </summary>
        ///// <param name="sender">The event sender</param>
        ///// <param name="e">The event arguments</param>
        //private void BackButton_Click(object sender, EventArgs e)
        //{
        //    int textLength = this.userInputText.Text.Length;

        //    if (textLength > 0)
        //    {
        //        this.userInputText.Text = this.userInputText.Text.Remove(textLength - 1);
        //    }


        //    FocusInputText();
        //}

        
        #endregion

        #region Operator Methods 

        /// <summary>
        /// Adds the / character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void DivideButton_Click(object sender, EventArgs e)
        {
            insertText("/");
            FocusInputText();
        }

        /// <summary>
        /// Adds the * character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void MultiplyButton_Click(object sender, EventArgs e)
        {
            insertText("*");
            FocusInputText();
        }

        /// <summary>
        /// Adds the - character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void SubtractButton_Click(object sender, EventArgs e)
        {
            insertText("-");
            FocusInputText();
        }

        /// <summary>
        /// Adds the + character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void AddButton_Click(object sender, EventArgs e)
        {
            insertText("+");
            FocusInputText();
        }

        /// <summary>
        /// ***************************************************************************
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void EqualsButton_Click(object sender, EventArgs e)
        {
            CalculateEquation();
        }



        #endregion

        #region Special Operator Methods

        /// <summary>
        /// Toggles the sign to the begining of the input text box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void SignChangeButton_Click(object sender, EventArgs e)
        {
            if(this.userInputText.Text.ElementAt(0) == '-')
            {
                this.userInputText.Text = this.userInputText.Text.Remove(0,1);
            }
            else
            {
                this.userInputText.Text = this.userInputText.Text.Insert(0, "-");
            }


            FocusInputText();
            // Restore selection start
            this.userInputText.SelectionStart = this.userInputText.Text.Length;

            // Set selection length to be zero
            this.userInputText.SelectionLength = 0;
        }

        /// <summary>
        /// Adds the . character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void DecimalButton_Click(object sender, EventArgs e)
        {
            insertText(".");
            FocusInputText();
        }

        #endregion

        #region Number Methods

        /// <summary>
        /// Adds the 0 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button0_Click(object sender, EventArgs e)
        {
            insertText("0");
            FocusInputText();
        }

        /// <summary>
        /// Adds the 1 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button1_Click(object sender, EventArgs e)
        {
            insertText("1");
            FocusInputText();
        }

        /// <summary>
        /// Adds the 2 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button2_Click(object sender, EventArgs e)
        {
            insertText("2");
            FocusInputText();
        }

        /// <summary>
        /// Adds the 3 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button3_Click(object sender, EventArgs e)
        {
            insertText("3");
            FocusInputText();
        }

        /// <summary>
        /// Adds the 4 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button4_Click(object sender, EventArgs e)
        {
            insertText("4");
            FocusInputText();
        }

        /// <summary>
        /// Adds the 5 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button5_Click(object sender, EventArgs e)
        {
            insertText("5");
            FocusInputText();
        }

        /// <summary>
        /// Adds the 6 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button6_Click(object sender, EventArgs e)
        {
            insertText("6");
            FocusInputText();
        }

        /// <summary>
        /// Adds the 7 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button7_Click(object sender, EventArgs e)
        {
            insertText("7");
            FocusInputText();
        }

        /// <summary>
        /// Adds the 8 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button8_Click(object sender, EventArgs e)
        {
            insertText("8");
            FocusInputText();
        }

        /// <summary>
        /// Adds the 9 character to the currently selected position in the user input box
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private void Button9_Click(object sender, EventArgs e)
        {
            insertText("9");
            FocusInputText();
        }

        #endregion

        #region Private Helpers Functions

        /// <summary>
        /// Focuses the user input text
        /// </summary>
        private void FocusInputText()
        {
            this.userInputText.Focus();
        }


        /// <summary>
        /// Inserts a string value to the left of the currently selected position within the user input box
        /// </summary>
        /// <param name="tooAdd">String argument added to text</param>
        private void insertText(string tooAdd)
        {

            // Remember selection start
            var SelectionStart = this.userInputText.SelectionStart;


            // Insert new string to the left of selection start
            this.userInputText.Text = this.userInputText.Text.Insert(this.userInputText.SelectionStart, tooAdd);


            // Restore selection start
            this.userInputText.SelectionStart = SelectionStart + tooAdd.Length;

            // Set selection length to be zero
            this.userInputText.SelectionLength = 0;
        }

        /// <summary>
        /// Deletes the character to the right of the currently selected position or does nothing if the user input text is empty 
        /// </summary>
        private void deleteText()
        {
            // If there is nothing to delete, do nothing
            if (this.userInputText.Text.Length < this.userInputText.SelectionStart + 1)
                return;

            // Remember selection start
            var SelectionStart = this.userInputText.SelectionStart;

            // Delete the character to the right of the selection
            this.userInputText.Text = this.userInputText.Text.Remove(this.userInputText.SelectionStart, 1);


            // Restore selection start
            this.userInputText.SelectionStart = SelectionStart;

            // Set selection length to be zero
            this.userInputText.SelectionLength = 0;
        }

        private void CalculateEquation()
        {
            var userInput = this.userInputText.Text;

            // 1. Enums
            // 2. New class files
            // 3. Recursive functions
            // 4. Switch Statements

            this.calculationResultText.Text = ParseOperation();

            FocusInputText();
        }


        /// <summary>
        /// Parses the users input/equation and computes the result
        /// </summary>
        /// <returns></returns>
        private string ParseOperation()
        {
            try
            {
                // Get the users equation input
                var input = this.userInputText.Text;

                // Remove all spaces
                input = input.Replace(" ", "");

                // Create a new top-level operation
                var operation = new Operation();
                var leftSide = true;


                // Loop through each character of the input
                // starting from the left working to the right
                for (int i = 0; i < input.Length; i++)
                {
                    // TODO: Handle order of operations
                    //      4 + 5 * 3
                    //      Should calculate 5 * 3 first, then 4 + the result (so 4 + 15)

                    //Check if the current character is a number
                    if ("0123456789.".Any(c => input[i] == c))
                    {
                        if (leftSide)
                            operation.leftSide = AddNumberPart(operation.leftSide, input[i]);
                        else
                        {
                            operation.rightSide = AddNumberPart(operation.rightSide, input[i]);
                        }
                    }

                    // If it is an operator ( + - * / ) set the operator type
                    else if ("+-*/".Any(c => input[i] == c))
                    {
                        // If we are on the right side already, we now need to calculate our current operation
                        // and set the result to the left side of the next operation
                        if (!leftSide)
                        {
                            // Get the operator type
                            var operatorType = GetOperationType(input[i]);

                            // Check if we actually have a right side number
                            if (operation.rightSide.Length == 0)
                            {
                                // Check the operator is not a minus (as they could be creating a negative number)
                                if (operatorType != OperationType.Subtract)
                                    throw new InvalidOperationException($"Operator (+ * / or more than one -) specified without a left side number");

                                // If we got here, the operator type is subtract, and there is no left side number currently, so add the minus to the number
                                operation.rightSide += input[i];

                            }
                            else
                            {
                                // Calculate previous equation and set to the left side
                                operation.leftSide = CalculateOperation(operation);

                                // Set new operator
                                operation.OperationType = operatorType;

                                // Clear the previous right number
                                operation.rightSide = string.Empty;
                            }
                        }
                        else
                        {
                            // Get the operator type
                            var operatorType = GetOperationType(input[i]);

                            // Check if we actually have a left side number
                            if (operation.leftSide.Length == 0)
                            {
                                // Check the operator is not a minus (as they could be creating a negative number)
                                if (operatorType != OperationType.Subtract)
                                    throw new InvalidOperationException($"Operator (+ * / or more than one -) specified without a left side number");

                                // If we got here, the operator type is subtract, and there is no left side number currently, so add the minus to the number
                                operation.leftSide += input[i];

                            }
                            else
                            {
                                // If we get here, we have a left number and now an operator, so we want to move to the right side

                                // Set the operation type
                                operation.OperationType = operatorType;


                                // Move to the right side
                                leftSide = false;

                            }
                        }
                    }
                }

                // If we are done parsing, and there were no exceptions
                // calculate the current operation
                return CalculateOperation(operation);
            }
            catch(Exception ex)
            {
                return $"Invalid equation. {ex.Message}";
            }
            
        }


        /// <summary>
        /// Calculates an <see cref="Operation"/> and returns the result
        /// </summary>
        /// <param name="operation">The operation to calculate</param>
        private string CalculateOperation(Operation operation)
        {
            // Store the number values of the string representations
            decimal left = 0;
            decimal right = 0;

            // Check if we have a valid left side number
            if (string.IsNullOrEmpty(operation.leftSide) || !decimal.TryParse(operation.leftSide, out left))
                throw new InvalidOperationException($"Left side of the operation was not a number. {operation.leftSide}");

            // Check if we have a valid right side number
            if (string.IsNullOrEmpty(operation.rightSide) || !decimal.TryParse(operation.rightSide, out right))
                throw new InvalidOperationException($"Right side of the operation was not a number. {operation.rightSide}");

            try
            {
                switch (operation.OperationType) 
                {
                    case OperationType.Add:
                        return (left + right).ToString();
                    case OperationType.Subtract:
                        return (left - right).ToString();
                    case OperationType.Multiply:
                        return (left * right).ToString();
                    case OperationType.Divide:
                        return (left / right).ToString();
                    default:
                        throw new InvalidOperationException($"Unknown operator type when calculating operation. {operation.OperationType}");
                }

            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to calculate operation {operation.leftSide} {operation.OperationType} {operation.rightSide}. {ex.Message}");
            }

            return string.Empty;
        }


        /// <summary>
        /// Accepts a character and returns the known <see cref="OperationType"/>
        /// </summary>
        /// <param name="character">The character to parse</param>
        /// <returns></returns>
        private OperationType GetOperationType(char character)
        {
            switch (character)
            {
                case '+':
                    return OperationType.Add;
                case '-':
                    return OperationType.Subtract;
                case '*':
                    return OperationType.Multiply;
                case '/':
                    return OperationType.Divide;
                default:
                    throw new InvalidOperationException($"Unknown operator type {character}");
            }


        }

        /// <summary>
        /// Attempts to add a new character to the current number, checking for valid characters as it goes
        /// </summary>
        /// <param name="currentNumber">The current number string</param>
        /// <param name="currentCharacter">The new character to append to the string</param>
        /// <returns></returns>
        private string AddNumberPart(string currentNumber, char newCharacter)
        {
            // Check if there is already a . in the number
            if (newCharacter == '.' && currentNumber.Contains('.'))
                throw new InvalidOperationException($"Number {currentNumber} already contains a . and another cannot be added");
   

            return currentNumber + newCharacter;
        }

        #endregion
    }
}
