﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    /// <summary>
    /// Holds information about a single calculator operation
    /// </summary>
    public class Operation
    {

        #region Public Properties

        /// <summary>
        /// The left side of the operation
        /// </summary>
        public string leftSide { get; set; }


        /// <summary>
        /// The right side of the operation
        /// </summary>
        public string rightSide { get; set; }


        /// <summary>
        /// The type of operation to perform
        /// </summary>
        public OperationType OperationType { get; set; }

        /// <summary>
        /// The inner operation to be performed initially before this operation
        /// </summary>
        public Operation InnerOperation { get; set; }

        #endregion

        #region Constructor


        /// <summary>
        /// Default Constructor
        /// </summary>
        public Operation()
        {
            // Create empty strings so operations do not have null values
            this.leftSide = string.Empty;
            this.rightSide = string.Empty;
        }

        #endregion
    }
}
