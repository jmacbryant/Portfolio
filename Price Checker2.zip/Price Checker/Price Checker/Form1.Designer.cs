﻿using System;

namespace Price_Checker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.OrderListText = new System.Windows.Forms.TextBox();
            this.PriceText = new System.Windows.Forms.TextBox();
            this.PriceLabel = new System.Windows.Forms.Label();
            this.YearText = new System.Windows.Forms.TextBox();
            this.YearLabel = new System.Windows.Forms.Label();
            this.ModelText = new System.Windows.Forms.TextBox();
            this.ModelLabel = new System.Windows.Forms.Label();
            this.BrandText = new System.Windows.Forms.TextBox();
            this.BrandLabel = new System.Windows.Forms.Label();
            this.AddItemButton = new System.Windows.Forms.Button();
            this.RemoveItemButton = new System.Windows.Forms.Button();
            this.OrderSubmitButton = new System.Windows.Forms.Button();
            this.FoundListText = new System.Windows.Forms.TextBox();
            this.FoundListLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.NotFoundListText = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.OrderSubmitButton);
            this.splitContainer1.Panel1.Controls.Add(this.RemoveItemButton);
            this.splitContainer1.Panel1.Controls.Add(this.AddItemButton);
            this.splitContainer1.Panel1.Controls.Add(this.OrderListText);
            this.splitContainer1.Panel1.Controls.Add(this.PriceText);
            this.splitContainer1.Panel1.Controls.Add(this.PriceLabel);
            this.splitContainer1.Panel1.Controls.Add(this.YearText);
            this.splitContainer1.Panel1.Controls.Add(this.YearLabel);
            this.splitContainer1.Panel1.Controls.Add(this.ModelText);
            this.splitContainer1.Panel1.Controls.Add(this.ModelLabel);
            this.splitContainer1.Panel1.Controls.Add(this.BrandText);
            this.splitContainer1.Panel1.Controls.Add(this.BrandLabel);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.label1);
            this.splitContainer1.Panel2.Controls.Add(this.NotFoundListText);
            this.splitContainer1.Panel2.Controls.Add(this.FoundListLabel);
            this.splitContainer1.Panel2.Controls.Add(this.FoundListText);
            this.splitContainer1.Size = new System.Drawing.Size(804, 461);
            this.splitContainer1.SplitterDistance = 402;
            this.splitContainer1.TabIndex = 0;
            // 
            // OrderListText
            // 
            this.OrderListText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OrderListText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OrderListText.Location = new System.Drawing.Point(3, 199);
            this.OrderListText.Multiline = true;
            this.OrderListText.Name = "OrderListText";
            this.OrderListText.ReadOnly = true;
            this.OrderListText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.OrderListText.Size = new System.Drawing.Size(393, 223);
            this.OrderListText.TabIndex = 8;
            // 
            // PriceText
            // 
            this.PriceText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PriceText.Location = new System.Drawing.Point(3, 137);
            this.PriceText.Name = "PriceText";
            this.PriceText.Size = new System.Drawing.Size(392, 20);
            this.PriceText.TabIndex = 7;
            // 
            // PriceLabel
            // 
            this.PriceLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PriceLabel.AutoSize = true;
            this.PriceLabel.Location = new System.Drawing.Point(3, 121);
            this.PriceLabel.Name = "PriceLabel";
            this.PriceLabel.Size = new System.Drawing.Size(74, 13);
            this.PriceLabel.TabIndex = 6;
            this.PriceLabel.Text = "Prefered Price";
            // 
            // YearText
            // 
            this.YearText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.YearText.Location = new System.Drawing.Point(3, 98);
            this.YearText.Name = "YearText";
            this.YearText.Size = new System.Drawing.Size(392, 20);
            this.YearText.TabIndex = 5;
            // 
            // YearLabel
            // 
            this.YearLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.YearLabel.AutoSize = true;
            this.YearLabel.Location = new System.Drawing.Point(3, 84);
            this.YearLabel.Name = "YearLabel";
            this.YearLabel.Size = new System.Drawing.Size(29, 13);
            this.YearLabel.TabIndex = 4;
            this.YearLabel.Text = "Year";
            // 
            // ModelText
            // 
            this.ModelText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ModelText.Location = new System.Drawing.Point(3, 61);
            this.ModelText.Name = "ModelText";
            this.ModelText.Size = new System.Drawing.Size(392, 20);
            this.ModelText.TabIndex = 3;
            // 
            // ModelLabel
            // 
            this.ModelLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ModelLabel.AutoSize = true;
            this.ModelLabel.Location = new System.Drawing.Point(3, 45);
            this.ModelLabel.Name = "ModelLabel";
            this.ModelLabel.Size = new System.Drawing.Size(36, 13);
            this.ModelLabel.TabIndex = 2;
            this.ModelLabel.Text = "Model";
            // 
            // BrandText
            // 
            this.BrandText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BrandText.Location = new System.Drawing.Point(3, 22);
            this.BrandText.Name = "BrandText";
            this.BrandText.Size = new System.Drawing.Size(392, 20);
            this.BrandText.TabIndex = 1;
            // 
            // BrandLabel
            // 
            this.BrandLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BrandLabel.AutoSize = true;
            this.BrandLabel.Location = new System.Drawing.Point(3, 6);
            this.BrandLabel.Name = "BrandLabel";
            this.BrandLabel.Size = new System.Drawing.Size(35, 13);
            this.BrandLabel.TabIndex = 0;
            this.BrandLabel.Text = "Brand";
            // 
            // AddItemButton
            // 
            this.AddItemButton.BackColor = System.Drawing.Color.Lime;
            this.AddItemButton.Location = new System.Drawing.Point(3, 163);
            this.AddItemButton.Name = "AddItemButton";
            this.AddItemButton.Size = new System.Drawing.Size(175, 30);
            this.AddItemButton.TabIndex = 9;
            this.AddItemButton.Text = "Add product to list";
            this.AddItemButton.UseVisualStyleBackColor = false;
            this.AddItemButton.Click += new System.EventHandler(this.addItemButton_Click);
            // 
            // RemoveItemButton
            // 
            this.RemoveItemButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RemoveItemButton.BackColor = System.Drawing.Color.Red;
            this.RemoveItemButton.ForeColor = System.Drawing.Color.White;
            this.RemoveItemButton.Location = new System.Drawing.Point(220, 163);
            this.RemoveItemButton.Name = "RemoveItemButton";
            this.RemoveItemButton.Size = new System.Drawing.Size(175, 30);
            this.RemoveItemButton.TabIndex = 10;
            this.RemoveItemButton.Text = "Remove last item from list";
            this.RemoveItemButton.UseVisualStyleBackColor = false;
            this.RemoveItemButton.Click += new System.EventHandler(this.RemoveItemButton_Click);
            // 
            // OrderSubmitButton
            // 
            this.OrderSubmitButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OrderSubmitButton.BackColor = System.Drawing.Color.Blue;
            this.OrderSubmitButton.ForeColor = System.Drawing.Color.White;
            this.OrderSubmitButton.Location = new System.Drawing.Point(0, 428);
            this.OrderSubmitButton.Name = "OrderSubmitButton";
            this.OrderSubmitButton.Size = new System.Drawing.Size(394, 29);
            this.OrderSubmitButton.TabIndex = 11;
            this.OrderSubmitButton.Text = "Check order availability in inventory";
            this.OrderSubmitButton.UseVisualStyleBackColor = false;
            this.OrderSubmitButton.Click += new System.EventHandler(this.OrderSubmitButton_Click);
            // 
            // FoundListText
            // 
            this.FoundListText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FoundListText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FoundListText.Location = new System.Drawing.Point(3, 64);
            this.FoundListText.Multiline = true;
            this.FoundListText.Name = "FoundListText";
            this.FoundListText.ReadOnly = true;
            this.FoundListText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.FoundListText.Size = new System.Drawing.Size(393, 148);
            this.FoundListText.TabIndex = 9;
            // 
            // FoundListLabel
            // 
            this.FoundListLabel.AutoSize = true;
            this.FoundListLabel.BackColor = System.Drawing.Color.Lime;
            this.FoundListLabel.Location = new System.Drawing.Point(4, 25);
            this.FoundListLabel.Name = "FoundListLabel";
            this.FoundListLabel.Size = new System.Drawing.Size(298, 13);
            this.FoundListLabel.TabIndex = 12;
            this.FoundListLabel.Text = "These are the items from your order we found in our inventory:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 262);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(335, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "These are the items from your order we could not find in our inventory:";
            // 
            // NotFoundListText
            // 
            this.NotFoundListText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.NotFoundListText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NotFoundListText.Location = new System.Drawing.Point(2, 301);
            this.NotFoundListText.Multiline = true;
            this.NotFoundListText.Name = "NotFoundListText";
            this.NotFoundListText.ReadOnly = true;
            this.NotFoundListText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.NotFoundListText.Size = new System.Drawing.Size(393, 148);
            this.NotFoundListText.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 461);
            this.Controls.Add(this.splitContainer1);
            this.MinimumSize = new System.Drawing.Size(820, 500);
            this.Name = "Form1";
            this.Text = "Form1";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox PriceText;
        private System.Windows.Forms.Label PriceLabel;
        private System.Windows.Forms.TextBox YearText;
        private System.Windows.Forms.Label YearLabel;
        private System.Windows.Forms.TextBox ModelText;
        private System.Windows.Forms.Label ModelLabel;
        private System.Windows.Forms.TextBox BrandText;
        private System.Windows.Forms.Label BrandLabel;
        private System.Windows.Forms.TextBox OrderListText;
        private System.Windows.Forms.Button AddItemButton;
        private System.Windows.Forms.Button RemoveItemButton;
        private System.Windows.Forms.Button OrderSubmitButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NotFoundListText;
        private System.Windows.Forms.Label FoundListLabel;
        private System.Windows.Forms.TextBox FoundListText;
    }
}

