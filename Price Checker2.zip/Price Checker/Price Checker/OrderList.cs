﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Price_Checker
{
    

    class OrderList
    {
        #region Public Properties

        /// <summary>
        /// A data structure to hold OrderItems
        /// </summary>
        public List<OrderItem> list { get; } = new List<OrderItem>();

        #endregion


        #region Constructors
        /// <summary>
        /// Default Constructor
        /// </summary>
        public OrderList()
        {

        }

        #endregion


        #region Public Methods
        /// <summary>
        /// Adds an OrderItem to the end of the list
        /// </summary>
        /// <param name="item">OrderItem to be added to the end of the list</param>
        public void AddOrderItem(OrderItem item)
        {
            list.Add(item);
        }

        /// <summary>
        /// Removes the last OrderItem from the list
        /// </summary>
        public void RemoveLastOrderItem()
        {
            // If the list is not empty
            if (list.Count > 0)
            {
                // Remove the last OrderItem from the list
                list.RemoveAt(list.Count - 1);
            }
        }

        /// <summary>
        /// Removes all OrderItems from the list
        /// </summary>
        public void RemoveAllOrderItems()
        {
            // If the list is not empty
            if (list.Count > 0)
            {
                // Removes all OrderItems from the list
                list.Clear();
            }
        }

        /// <summary>
        /// Returns the contents of list in one string using the ToString() for each element on a seperate line
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            string toReturn = "";

            for (int i = 0; i < list.Count; i++)
            {
                toReturn += list[i].ToString();
            }
            return toReturn;
        }

        /// <summary>
        /// Returns the number of elements contained in list
        /// </summary>
        /// <returns></returns>
        public int Size()
        {
            return list.Count;
        }

        public OrderItem this[int i]
        {
            get { return list[i]; }
        }
        #endregion
    }
}
