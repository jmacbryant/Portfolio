﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Price_Checker
{
    public partial class Form1 : Form
    {

        #region Properties
        /// <summary>
        /// The order list that is desired by the user
        /// </summary>
        OrderList wishList = new OrderList();

        /// <summary>
        /// The order list that is desired by the user AND found in the database inventory
        /// </summary>
        OrderList foundList = new OrderList();

        /// <summary>
        /// The order list that is desired by the user BUT not found in the database inventory
        /// </summary>
        OrderList notFoundList = new OrderList();

        #endregion

        #region Constructors

        /// <summary>
        /// Default Constructor
        /// </summary>
        public Form1()
        {
            InitializeComponent();  
        }

        #endregion

        #region Click Events

        private void addItemButton_Click(object sender, EventArgs e)
        {

            // Create a new OrderItem based on the text fields on the left-side of the form
            OrderItem item = new OrderItem(this.BrandText.Text, this.ModelText.Text, this.YearText.Text, this.PriceText.Text);

            // Add the new OrderItem to the wishList
            this.wishList.AddOrderItem(item);

            // Display the wishList to the OrderListText textbox on the form
            this.OrderListText.Text = wishList.ToString();
        }

        private void RemoveItemButton_Click(object sender, EventArgs e)
        {
            // If the wishlist is not empty
            if (wishList.list.Count != 0)
            {
                // Remove the last OrderItem from the wishList
                this.wishList.RemoveLastOrderItem();

                // Display the wishList to the OrderListText textbox on the form
                this.OrderListText.Text = wishList.ToString();
            }
        }

        private void OrderSubmitButton_Click(object sender, EventArgs e)
        {
            CheckOrderInventoryAvailability();
            
        }

        //private void dbButton_Click(object sender, EventArgs e)
        //{
        //    //Obtaining the data source
        //    var Inventory = new InventoryDataContext();

        //    // Create the query
        //    var query = from c in Inventory.Products
        //                select c;


        //    dbOutput.Text += "\n UPC \t ProductBrand \t ProductModel \t ProductYear \t Price \t CreatedBy \t CreatedDate \t UpdatedBy \t UpdatedDate \t RowStamp";
        //    // Execute the query
        //    foreach (var c in query)
        //    {
        //        //dbOutput.Text += "\n" + (c.ProductBrand);
        //        dbOutput.Text += "\n" + c.UPC + " _ " + c.ProductBrand + " _ " + c.ProductModel + " _ " + c.ProductYear.Year + " _ " + c.Price + " _ " + c.CreatedBy + " _ " + c.CreatedDate + " _ " + c.UpdatedBy + " _ " + c.UpdatedDate + " _ " + c.RowStamp;
        //    }
        //}


        #endregion

        #region Public Methods

        /// <summary>
        /// Takes the requested order from the user and attempts to find each OrderItem in the inventory database
        /// 
        /// -Adds OrderItems that are found in the inventory database to the foundList
        /// -Adds OrderItems that are not found in the inventory database to the notFoundList
        /// </summary>
        private void CheckOrderInventoryAvailability()
        {
            // Clear the OrderItems from the foundList and notFoundList
            foundList.RemoveAllOrderItems();
            notFoundList.RemoveAllOrderItems();


            // Search for each OrderItem from wishList in the inventory database

            // If the OrderItem is found in the inventory database
            // Add the OrderItem to the foundList

            // If the OrderItem is found in the inventory database
            // Add the OrderItem to the foundList

            // FINISH THIS METHOD
            this.FoundListText.Text += "Functionality Currently Unavailable" + Environment.NewLine;
            this.NotFoundListText.Text += "Functionality Currently Unavailable" + Environment.NewLine;


            //Obtaining the data source
            var Inventory = new InventoryDataContext();

            // Create the query
            var query = from c in Inventory.Products
                        select c;

            string t = "";
            /// += "\n UPC \t ProductBrand \t ProductModel \t ProductYear \t Price \t CreatedBy \t CreatedDate \t UpdatedBy \t UpdatedDate \t RowStamp";
            // Execute the query
            int wishListSize = wishList.Size();
            bool found;
            for (int i = 0; i < wishListSize; i++)
            {
                found = false;
                OrderItem find = wishList[i];
                foreach (var c in query)
                {

                    if (find.ProductBrand == c.ProductBrand && find.ProductModel == c.ProductModel)
                    {
                        find.UPC = c.UPC.ToString();
                        foundList.AddOrderItem(find);
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    notFoundList.AddOrderItem(find);
                }
            }
            this.FoundListText.Text = foundList.ToString();
            this.NotFoundListText.Text = notFoundList.ToString();

        }

        #endregion
    }
}
