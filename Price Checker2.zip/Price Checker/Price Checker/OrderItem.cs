﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Price_Checker
{
    class OrderItem
    {

        #region Public Properties

        /// <summary>
        /// The brand name of the desired product 
        /// </summary>
        public string ProductBrand { get; set; }

        /// <summary>
        /// The model name of the desired product 
        /// </summary>
        public string ProductModel { get; set; }

        /// <summary>
        /// The year the desired product was manufactured
        /// </summary>
        public string ProductYear { get; set; }

        /// <summary>
        /// The desired price of the desired product
        /// </summary>
        public string Price { get; set; }

        /// <summary>
        /// The Unique Product Code (only seen if found in the database)
        /// </summary>
        public string UPC { get; set; }


        #endregion


        #region Constructors
        /// <summary>
        /// Default Constructor
        /// </summary>
        public OrderItem()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="brand">ProductBrand property will be set to this value</param>
        /// <param name="model">ProductModel property will be set to this value</param>
        /// <param name="year">ProductYear property will be set to this value</param>
        /// <param name="price">Price property will be set to this value</param>
        public OrderItem(string brand, string model, string year, string price)
        {
            ProductBrand = brand;
            ProductModel = model;
            ProductYear = year;
            Price = price;
        }

        #endregion

        #region Public Methods

        public override string ToString()
        {
            if(this.UPC == "")
            {
                return ProductBrand + ", " + ProductModel + ", " + ProductYear + ", " + Price + Environment.NewLine;
            }
            else
            {
                return UPC + ", " + ProductBrand + ", " + ProductModel + ", " + ProductYear + ", " + Price + Environment.NewLine;
            }
        }

        #endregion
    }
}
